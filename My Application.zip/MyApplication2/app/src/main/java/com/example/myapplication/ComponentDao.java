package com.example.myapplication;

import androidx.room.*;
import java.util.List;

@Dao
public interface ComponentDao {
    @Insert
    long insert(Component component);

    @Update
    void update(Component component);

    @Delete
    void delete(Component component);

    @Query("SELECT * FROM components ORDER BY name ASC")
    List<Component> getAllComponents();

    @Query("SELECT * FROM components WHERE name LIKE :query OR sku LIKE :query OR category LIKE :query")
    List<Component> searchComponents(String query);

    @Query("SELECT * FROM components WHERE quantity < minStock")
    List<Component> getLowStockItems();

    @Query("SELECT * FROM components WHERE id = :id")
    Component getComponentById(int id);

    @Query("UPDATE components SET quantity = quantity + :amount WHERE id = :id")
    void updateQuantity(int id, int amount);

    @Query("SELECT COUNT(*) FROM components")
    int getTotalCount();

    @Query("SELECT SUM(quantity) FROM components")
    Integer getTotalQuantity();
}