package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity implements ComponentAdapter.OnComponentClickListener {

    private RecyclerView recyclerView;
    private ComponentAdapter adapter;
    private AppDatabase db;
    private ExecutorService executor;
    private EditText searchEditText;
    private TextView textStats;
    private Button btnAdd;
    private List<Component> allComponents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_simple);


        db = AppDatabase.getDatabase(this);
        executor = Executors.newSingleThreadExecutor();

        btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
            startActivity(intent);
        });


        searchEditText = findViewById(R.id.searchEditText);
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                search(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });


        textStats = findViewById(R.id.textStats);


        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ComponentAdapter(this);
        recyclerView.setAdapter(adapter);


        loadComponents();
        checkLowStockOnStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadComponents();
    }


    private void loadComponents() {
        executor.execute(() -> {
            allComponents = db.componentDao().getAllComponents();
            int total = db.componentDao().getTotalCount();
            Integer totalQty = db.componentDao().getTotalQuantity();

            runOnUiThread(() -> {
                adapter.setComponents(allComponents);
                textStats.setText(String.format("Товаров: %d | Всего: %d шт.",
                        total, totalQty != null ? totalQty : 0));
            });
        });
    }


    private void search(String query) {
        if (allComponents == null) return;

        String lowerQuery = query.toLowerCase();
        List<Component> filtered = new java.util.ArrayList<>();

        for (Component c : allComponents) {
            if (c.getName().toLowerCase().contains(lowerQuery) ||
                    c.getSku().toLowerCase().contains(lowerQuery) ||
                    c.getCategory().toLowerCase().contains(lowerQuery)) {
                filtered.add(c);
            }
        }

        runOnUiThread(() -> adapter.setComponents(filtered));
    }


    private void checkLowStockOnStart() {
        executor.execute(() -> {
            List<Component> lowStock = db.componentDao().getLowStockItems();
            if (!lowStock.isEmpty()) {
                runOnUiThread(() -> {
                    new AlertDialog.Builder(this)
                            .setTitle("Низкий остаток")
                            .setMessage(getLowStockMessage(lowStock))
                            .setPositiveButton("OK", null)
                            .show();
                });
            }
        });
    }

    private String getLowStockMessage(List<Component> list) {
        StringBuilder sb = new StringBuilder();
        for (Component c : list) {
            sb.append("• ").append(c.getName())
                    .append(" (осталось: ").append(c.getQuantity()).append(")\n");
        }
        return sb.toString();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_report) {
            showReport();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void showReport() {
        executor.execute(() -> {
            List<Component> lowStock = db.componentDao().getLowStockItems();
            int total = db.componentDao().getTotalCount();

            runOnUiThread(() -> {
                String message = String.format(
                        "ОТЧЁТ ПО СКЛАДУ\n\n" +
                                "Всего товаров: %d\n" +
                                "Требуют пополнения: %d\n\n",
                        total, lowStock.size()
                );

                if (!lowStock.isEmpty()) {
                    message += getLowStockMessage(lowStock);
                } else {
                    message += " Все товары в норме!";
                }

                new AlertDialog.Builder(this)
                        .setTitle("Отчёт")
                        .setMessage(message)
                        .show();
            });
        });
    }



    @Override
    public void onEdit(Component component) {
        Intent intent = new Intent(this, AddEditActivity.class);
        intent.putExtra("component_id", component.getId());
        startActivity(intent);
    }

    @Override
    public void onStockOperation(Component component) {
        new AlertDialog.Builder(this)
                .setTitle(component.getName())
                .setMessage("Остаток: " + component.getQuantity() + " шт.\nВыберите операцию:")
                .setPositiveButton("➕ Приход (+1)", (d, w) -> updateStock(component.getId(), 1))
                .setNeutralButton("➕ Приход (+10)", (d, w) -> updateStock(component.getId(), 10))
                .setNegativeButton("➖ Расход (-1)", (d, w) -> updateStock(component.getId(), -1))
                .show();
    }

    @Override
    public void onDelete(Component component) {
        new AlertDialog.Builder(this)
                .setTitle("Удалить товар?")
                .setMessage(component.getName())
                .setPositiveButton("Удалить", (d, w) -> {
                    executor.execute(() -> {
                        db.componentDao().delete(component);
                        runOnUiThread(() -> {
                            loadComponents();
                            Toast.makeText(MainActivity.this, "Удалено", Toast.LENGTH_SHORT).show();
                        });
                    });
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void updateStock(int id, int amount) {
        executor.execute(() -> {
            db.componentDao().updateQuantity(id, amount);
            runOnUiThread(() -> {
                loadComponents();
                Toast.makeText(this,
                        (amount > 0 ? "➕ Приход: " : "➖ Расход: ") + Math.abs(amount) + " шт.",
                        Toast.LENGTH_SHORT).show();
            });
        });
    }


    private void addTestComponents() {
        executor.execute(() -> {
            db.componentDao().insert(new Component("GeForce RTX 3060", "Видеокарты", "GPU-001", 10, 5, "A-12", 25000, 35000));
            db.componentDao().insert(new Component("Intel Core i5-12400F", "Процессоры", "CPU-001", 15, 3, "B-05", 12000, 18000));
            db.componentDao().insert(new Component("DDR4 16GB Kingston", "ОЗУ", "RAM-001", 2, 5, "C-08", 4000, 6500));
            db.componentDao().insert(new Component("Be Quiet! 600W", "Блоки питания", "PSU-001", 8, 4, "D-03", 5500, 8000));

            runOnUiThread(() -> {
                loadComponents();
                Toast.makeText(this, "Добавлено 4 тестовых товара", Toast.LENGTH_LONG).show();
            });
        });
    }
}