package com.example.myapplication;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AddEditActivity extends AppCompatActivity {

    private EditText editName, editSku, editLocation, editMinStock, editPriceBuy, editPriceSell;
    private Spinner spinnerCategory;
    private NumberPicker pickerQuantity;
    private Button btnSave;
    private AppDatabase db;
    private ExecutorService executor;
    private int componentId = -1;

    private String[] categories = {"Видеокарты", "Процессоры", "ОЗУ", "Блоки питания",
            "Материнские платы", "Накопители", "Корпуса", "Другое"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);

        db = AppDatabase.getDatabase(this);
        executor = Executors.newSingleThreadExecutor();


        editName = findViewById(R.id.editName);
        editSku = findViewById(R.id.editSku);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        pickerQuantity = findViewById(R.id.pickerQuantity);
        editLocation = findViewById(R.id.editLocation);
        editMinStock = findViewById(R.id.editMinStock);
        editPriceBuy = findViewById(R.id.editPriceBuy);
        editPriceSell = findViewById(R.id.editPriceSell);
        btnSave = findViewById(R.id.btnSave);

        // Настройка Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        // Настройка NumberPicker
        pickerQuantity.setMinValue(0);
        pickerQuantity.setMaxValue(1000);
        pickerQuantity.setValue(0);

        // Проверка режима (добавление или редактирование)
        componentId = getIntent().getIntExtra("component_id", -1);
        if (componentId != -1) {
            loadComponentForEdit();
            getSupportActionBar().setTitle("Редактировать");
        } else {
            getSupportActionBar().setTitle("Добавить товар");
        }

        // Сохранение
        btnSave.setOnClickListener(v -> saveComponent());
    }

    private void loadComponentForEdit() {
        executor.execute(() -> {
            Component component = db.componentDao().getComponentById(componentId);
            runOnUiThread(() -> {
                editName.setText(component.getName());
                editSku.setText(component.getSku());

                // Выбор категории
                for (int i = 0; i < categories.length; i++) {
                    if (categories[i].equals(component.getCategory())) {
                        spinnerCategory.setSelection(i);
                        break;
                    }
                }

                pickerQuantity.setValue(component.getQuantity());
                editLocation.setText(component.getLocation());
                editMinStock.setText(String.valueOf(component.getMinStock()));
                editPriceBuy.setText(String.valueOf(component.getPriceBuy()));
                editPriceSell.setText(String.valueOf(component.getPriceSell()));
            });
        });
    }

    private void saveComponent() {
        String name = editName.getText().toString().trim();
        String sku = editSku.getText().toString().trim();
        String location = editLocation.getText().toString().trim();

        if (name.isEmpty()) {
            editName.setError("Введите название");
            return;
        }
        if (sku.isEmpty()) {
            editSku.setError("Введите артикул");
            return;
        }

        int quantity = pickerQuantity.getValue();
        int minStock;
        double priceBuy, priceSell;

        try {
            minStock = Integer.parseInt(editMinStock.getText().toString());
            priceBuy = Double.parseDouble(editPriceBuy.getText().toString());
            priceSell = Double.parseDouble(editPriceSell.getText().toString());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Проверьте числовые поля", Toast.LENGTH_SHORT).show();
            return;
        }

        Component component = new Component(
                name,
                categories[spinnerCategory.getSelectedItemPosition()],
                sku,
                quantity,
                minStock,
                location,
                priceBuy,
                priceSell
        );

        executor.execute(() -> {
            if (componentId != -1) {
                component.setId(componentId);
                db.componentDao().update(component);
            } else {
                db.componentDao().insert(component);
            }

            runOnUiThread(() -> {
                Toast.makeText(this, "Сохранено!", Toast.LENGTH_SHORT).show();
                finish();
            });
        });
    }
}