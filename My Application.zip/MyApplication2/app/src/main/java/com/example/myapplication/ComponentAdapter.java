package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ComponentAdapter extends RecyclerView.Adapter<ComponentAdapter.ViewHolder> {
    private List<Component> components;
    private OnComponentClickListener listener;

    public interface OnComponentClickListener {
        void onEdit(Component component);
        void onStockOperation(Component component);
        void onDelete(Component component);
    }

    public ComponentAdapter(OnComponentClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_component, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Component component = components.get(position);

        holder.textName.setText(component.getName());
        holder.textSku.setText("Артикул: " + component.getSku());
        holder.textCategory.setText(component.getCategory());
        holder.textQuantity.setText("Остаток: " + component.getQuantity());
        holder.textLocation.setText("Ячейка: " + component.getLocation());
        holder.textPrice.setText(String.format("%.2f ₽", component.getPriceSell()));

        // Индикация низкого остатка
        if (component.isLowStock()) {
            holder.cardView.setCardBackgroundColor(0xFFFFEBEE);
            holder.textQuantity.setTextColor(0xFFD32F2F);
        } else {
            holder.cardView.setCardBackgroundColor(0xFFFFFFFF);
            holder.textQuantity.setTextColor(0xFF2E7D32);
        }

        holder.btnEdit.setOnClickListener(v -> listener.onEdit(component));
        holder.btnStock.setOnClickListener(v -> listener.onStockOperation(component));
        holder.btnDelete.setOnClickListener(v -> listener.onDelete(component));
    }

    @Override
    public int getItemCount() {
        return components == null ? 0 : components.size();
    }

    public void setComponents(List<Component> components) {
        this.components = components;
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView textName, textSku, textCategory, textQuantity, textLocation, textPrice;
        View btnEdit, btnStock, btnDelete;

        ViewHolder(View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView);
            textName = itemView.findViewById(R.id.textName);
            textSku = itemView.findViewById(R.id.textSku);
            textCategory = itemView.findViewById(R.id.textCategory);
            textQuantity = itemView.findViewById(R.id.textQuantity);
            textLocation = itemView.findViewById(R.id.textLocation);
            textPrice = itemView.findViewById(R.id.textPrice);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnStock = itemView.findViewById(R.id.btnStock);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}