package com.example.myapplication;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "components")
public class Component {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String name;
    private String category;
    private String sku;
    private int quantity;
    private int minStock;
    private String location;
    private double priceBuy;
    private double priceSell;

    public Component(String name, String category, String sku, int quantity,
                     int minStock, String location, double priceBuy, double priceSell) {
        this.name = name;
        this.category = category;
        this.sku = sku;
        this.quantity = quantity;
        this.minStock = minStock;
        this.location = location;
        this.priceBuy = priceBuy;
        this.priceSell = priceSell;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getSku() { return sku; }
    public void setSku(String sku) { this.sku = sku; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public int getMinStock() { return minStock; }
    public void setMinStock(int minStock) { this.minStock = minStock; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public double getPriceBuy() { return priceBuy; }
    public void setPriceBuy(double priceBuy) { this.priceBuy = priceBuy; }
    public double getPriceSell() { return priceSell; }
    public void setPriceSell(double priceSell) { this.priceSell = priceSell; }

    public boolean isLowStock() {
        return quantity < minStock;
    }
}